"""Ledger utilities."""

TAA_ACCEPTED_RECORD_TYPE = "taa_accepted"
