"""Version definitions for this protocol."""

versions = [
    {
        "major_version": 0,
        "minimum_minor_version": 1,
        "current_minor_version": 1,
        "path": "v0_1",
    }
]
