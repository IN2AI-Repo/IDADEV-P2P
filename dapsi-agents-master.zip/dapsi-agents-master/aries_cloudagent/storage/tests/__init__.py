"""
Storage test suite
"""
