"""
Wallet test suite
"""
