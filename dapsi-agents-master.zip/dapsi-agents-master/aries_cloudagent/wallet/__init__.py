"""Abstract and Indy wallet handling."""
