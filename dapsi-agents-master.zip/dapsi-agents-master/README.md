# IDADEV Hyperledger Aries implementation

## Table of contents
---
- [Schema](#schema)
- [Running locally](#running-locally)
  - [Ledger: Hyperledger Indy VON Network](#ledger-hyperledger-indy-von-network)
  - [Agents deployment](#agents-deployment)
- [Demo guide](#demo-guide)
- [Performed Demo](#performed-demo)

---

## Schema

The following figure shows an architecture of the three agents implemented:
- [IDADEV_P2P](/demo/runners/IDADEV.py)
- [Merchant](/demo/runners/Merchant.py)
- [Alice](/demo/runners/Alice.py)

![Hyperledger Schema](images/Hyperledger_Schema.jpg)

The process can be summarized in the following steps:
- Registration of IDADEV-P2P on the ledger
- IDADEV-P2P gets a public DID
- IDADEV-P2P register the schema and the credential definition (not in the Figure to make it easier to understand) on the ledger
- Registration of Merchant on the ledger
- Merchant gets a public DID
- Alice connects with IDADEV-P2P
- IDADEV-P2P issues a credential to Alice (when she registers her personal data in the Personal Data Store application)
- Alice receives a credential from IDADEV-P2P and stores is in her wallet
- Alice connects with Merchant
- Merchant sends a proof request to Alice
- Alice sends a proof to Merchant
- Merchant verifies the proof
- If the proof is valid, Merchant sends a voucher or promotional code to Alice

**The same process is described in the Technical Architecture document.*
Demo
---

## Running locally

**NOTE: The Agent's code allows to run the demo without any GUI.**

Prerequisites:
- [docker](https://docs.docker.com/engine/install/ubuntu/) must be installed 
- [docker-compose](https://docs.docker.com/compose/install/) must be installed

### Ledger: Hyperledger Indy VON Network

The VON network is used as the Indy ledger running a `localhost` instance in the current agent's implementation.

Follow the instructions of the next tutorial to run a local VON network instance.

- [VON Network](https://github.com/bcgov/von-network)
- [Running VON Network locally](https://github.com/bcgov/von-network/blob/master/docs/UsingVONNetwork.md)

### Agents deployment

Once you have your localhost instance of the VON Network running, you are ready to run the following commands to start the agents.

```
$ git clone https://gitlab.com/in2ai1/dapsi-agents.git
$ cd dapsi-agents/demo
```

There are three agents, so you will need three terminals. In each terminal run the following command:

- For Alice: `$ ./run_demo Alice`
- For IDADEV-P2P: `$ ./run_demo IDADEV`

*NOTE: This process may take a while. Please wait.*

We recommend not to start now the Merchant agent because we will make some changes in the code before running. This will be explained in the following section.

---

### Demo guide

In the `IDADEV` agent terminal you will see an invitation link. Copy it into the `Alice` agent terminal and press enter.

Now in the `IDADEV` agent terminal you can issue a credential to Alice, press `1`. Consequently, Alice will receive the credential and you can check it in its terminal.

From the `Alice` terminal save the last to outputs (NOTE: you will have different outputs):

```
Alice      | Credential definition ID:  YMt3CfpU3erQkVKBfznXNS:3:CL:22:default
Alice      | Schema ID:  YMt3CfpU3erQkVKBfznXNS:2:personal_data_schema:99.94.36
```

We will use the `Credential definition ID` and the `version`, which is the number at the end of the `Schema ID`.

Open the file `Merchant.py` and in line `200` and `211` set the `cred_def_id` from the previous output. Do the same with line `202` and `213` introducing the version, in this example `99.94.36`, you will have a different version.

After that, now you can run the `Merchant` agent:

`$ ./run_demo Merchant`

You will see an invitation in the same form as previously in `IDADEV` agent. Copy this invitation into the `Alice` agent.

In the `Alice` agent terminal press `2` to introduce a new invitation, then copy the `Merchant` invitation.

Go to the `Merchant` terminal and press `1` to request `Alice` a proof. Then automatically `Alice` will send a proof to `Merchant`. The `Merchant` will verify the proof and if everything goes well you will se this on the `Merchant` terminal:

```
Merchant   | Proof verification result: true
Merchant   | ----------------------------------------------------------------------------------
Merchant   | Proof claims:
Merchant   |     service: Amazon
Merchant   |     checksum: 84a3f860d54f3f5f65e91df081c8d776e8bcfb5fbc234afce2f0d7e9d26e160d
Merchant   | ----------------------------------------------------------------------------------
Merchant   | Claims verification completed successfully
Merchant   | Sending voucher to user
Merchant   | ----------------------------------------------------------------------------------
Merchant   | Schema ID and Credential Definition ID of presented claims:
Merchant   |     schema_id:   YMt3CfpU3erQkVKBfznXNS:2:personal_data_schema:99.94.36
Merchant   |     cred_def_id: YMt3CfpU3erQkVKBfznXNS:3:CL:22:default
Merchant   | ----------------------------------------------------------------------------------
Merchant   | Received message: Alice Agent received your message
-----------------------------------------------------------------------------------------------
```

In the `Alice` terminal you will see the following:

```
Alice      | Query for credentials in the wallet that satisfy the proof request
Alice      | Generate the proof
Alice      | Presentation (0923a11a-f2bd-4714-8af3-1122199eb37d) state = presentation_sent
Alice      | Presentation (0923a11a-f2bd-4714-8af3-1122199eb37d) state = presentation_acked
Alice      | Received message: Voucher received from Merchant Agent : SJR7 - 93B5 - MN0u - 7EJ3
```

---

## Performed Demo

If you don't want to run the code or you are having problems with the code, please check the Performed Demo to see the agent's interaction.

Go to [Performed Demo](demo.md)