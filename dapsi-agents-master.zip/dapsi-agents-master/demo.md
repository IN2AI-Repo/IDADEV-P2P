# Performed demo

In case you have problems to run a local instance of the agents or the VON Networks, the following demo will show how the interaction between agents works.

---

## IDADEV Agent

---

### DID Registration
![Alice_Agent](images/demo/IDADEV_ledger_DID_registration.png)

### Schema and Credential Definition registration
![Alice_Agent](images/demo/IDADEV_ledger_schema_and_cred_def.png)

### IDADEV connects with Alice
![Alice_Agent](images/demo/IDADEV_Agent_1.png)
![Alice_Agent](images/demo/IDADEV_Agent_2.png)
![Alice_Agent](images/demo/IDADEV_Agent_3.png)

### IDADEV sends the credential to Alice
![Alice_Agent](images/demo/IDADEV_Agent_4.png)

---

## Alice Agent

---

### Alice connects with IDADEV 
![Alice_Agent](images/demo/ALICE_Agent_1.png)
![Alice_Agent](images/demo/ALICE_Agent_2.png)

### Alice receives the credential from IDADEV
![Alice_Agent](images/demo/ALICE_Agent_3.png)

### Alice connects with Merchant
![Alice_Agent](images/demo/ALICE_Agent_4.png)
![Alice_Agent](images/demo/ALICE_Agent_5.png)

### Alice proofs to Merchant that she owns personal data from another Merchant
![Alice_Agent](images/demo/ALICE_Agent_6.png)

---

## Merchant Agent

---

### DID Registration
![Alice_Agent](images/demo/Merchant_ledger_DID_registration_1.png)
![Alice_Agent](images/demo/Merchant_ledger_DID_registration_2.png)

### Merchant connects with Alice
![Alice_Agent](images/demo/Merchant_Agent_1.png)
![Alice_Agent](images/demo/Merchant_Agent_2.png)

### Merchant requests the proof to Alice
![Alice_Agent](images/demo/Merchant_Agent_3.png)
![Alice_Agent](images/demo/Merchant_Agent_4.png)