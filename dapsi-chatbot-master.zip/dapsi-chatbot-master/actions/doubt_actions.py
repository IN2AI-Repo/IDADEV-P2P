from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import AllSlotsReset
from actions.trigger_actions import r_button, r_path, r_text, r_card


class SeeMoreMenus(Action):
    def name(self) -> Text:
        return 'action_see_more_menus'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text("Do you want to see the next menu?"),
                    r_button(['Yes', 'No'])]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]



class WhatCanDo(Action):
    def name(self) -> Text:
        return 'action_what_can_you_do'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text('Well, I know a lot about this app. You can ask me for any menu or directly ask me to take you to it. También se un poco sobre la GDPR, asi que puedes preguntarme sobre eso también.'),
                    r_text('Do you want explanations about the menus?'),
                    r_button(['Yes', 'No'])]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class WhatIsMyData(Action):
    def name(self) -> Text:
        return 'action_what_is_my_data'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_path('/mydata'),
                    r_text("Here you can keep track of all your personal information recovered from all this platforms and data sources.")]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class WhatIsMarketplace(Action):
    def name(self) -> Text:
        return 'action_what_is_marketplace'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_path('/marketplace'),
                    r_text("Many internet platforms and companies are interested in data from real people to improve their products.")]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class WhatIsDataAcademy(Action):
    def name(self) -> Text:
        return 'action_what_is_data_academy'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_path('/data-academy'),
                    r_text("Data Academy contains lots of articles to learn about privacy and data protection")]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class WhatIsDashboard(Action):
    def name(self) -> Text:
        return 'action_what_is_dashboard'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_path('/dashboard'),
                    r_text("Dashboard is where you can see your things.")]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]
