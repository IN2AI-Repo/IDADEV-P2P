from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import AllSlotsReset
from actions.trigger_actions import r_button, r_path, r_text, r_card
from actions.companies import data_companies


class OrganisationSchema(Action):

    def name(self) -> Text:
        return "action_organisation_schema"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        organisation = tracker.get_slot('first_organ')
        response = [r_text('Here you can see the details of {}'.format(data_companies[organisation]['name'])),
                    r_path('/company-detail/{}'.format(data_companies[organisation]['id']))]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class SchemaComparison(Action):

    def name(self) -> Text:
        return "action_schema_comparison"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        orgs = [tracker.get_slot('first_organ'), tracker.get_slot('second_organ')]
        if orgs[0] and orgs[1]:
            response = [r_text('Here you can see the details of {} and {} to compare'
                               .format(data_companies[orgs[0]]['name'], data_companies[orgs[1]]['name'])),
                        r_path('/comparing/{}/vs/{}'
                               .format(data_companies[orgs[0]]['id'], data_companies[orgs[1]]['id']))]
            dispatcher.utter_custom_json({'events': response})
        else:
            dispatcher.utter_message('I need 2 companies in order to compare them.')

        return [AllSlotsReset()]


class RecoverData(Action):
    def name(self) -> Text:
        return 'action_recover_data'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        org = data_companies[tracker.get_slot('first_organ')]

        response = [r_text('You can recover your data from {} right here'.format(org['name'])),
                    r_path('/recover-data/{}'.format(org['id']))]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class WhatDataHave(Action):
    def name(self) -> Text:
        return 'action_what_data_have'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        org = data_companies[tracker.get_slot('first_organ')]

        response = [r_text('{} has this information about you.'.format(org['name'])),
                    r_path('/company-detail/{}?location=whatDataHave  '.format(org['id']))]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]

