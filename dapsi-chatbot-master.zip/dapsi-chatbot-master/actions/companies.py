data_companies = {
  'amazon': {
    'id': 1,
    'name': 'Amazon',
    'image': 'amazon'
  },
  'apple': {
    'id': 2,
    'name': 'Apple',
    'image': 'apple'
  },
  'el corte ingles': {
    'id': 3,
    'name': 'El Corte Inglés',
    'image': 'elcortesingles'
  },
  'facebook': {
    'id': 4,
    'name': 'Facebook',
    'image': 'facebook'
  },
  'google': {
    'id': 5,
    'name': 'Google',
    'image': 'google'
    
  },
  'inditex': {
    'id': 6,
    'name': 'Inditex',
    'image': 'inditex'
  },
  'fnac': {
    'id': 7,
    'name': 'Fnac',
    'image': 'fnac'
  },
  'twitter': {
    'id': 8,
    'name': 'Twitter',
    'image': 'twitter'
  },
  'netflix': {
    'id': 9,
    'name': 'Netflix',
    'image': 'netflix'
  },
  'bbva': {
    'id': 10,
    'name': 'BBVA',
    'image': 'bbva',
  },
  'tiktok': {
    'id': 11,
    'name': 'TikTok',
    'image': 'tiktok',
  },
  'spotify': {
    'id': 12,
    'name': 'Spotify',
    'image': 'spotify'
  },
  'strava': {
    'id': 13,
    'name': 'Strava',
    'image': 'strava'
  },
  'alibaba': {
    'id': 14,
    'name': 'Alibaba',
    'image': 'alibaba'
  },
  'airbnb': {
    'id': 15,
    'name': 'Airbnb',
    'image': 'airbnb'
  },
  'disney': {
    'id': 16,
    'name': 'Disney',
    'image': 'disney'
  },
  'ebay': {
    'id': 17,
    'name': 'Ebay',
    'image': 'ebay'
  },
  'github': {
    'id': 18,
    'name': 'GitHub',
    'image': 'github'
  }
}