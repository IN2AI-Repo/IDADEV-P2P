from typing import Dict, Text, List, Optional, Any

from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormValidationAction
from actions.companies import data_companies


def get_orgs(tracker: Tracker, dispatcher):
    org = tracker.get_slot('ORG') if tracker.get_slot('ORG') else []
    organisation = tracker.get_slot('organisation') if tracker.get_slot('organisation') else []
    if type(org) != list:
        org = [org]
    if type(organisation) != list:
        organisation = [organisation]
    organisations = list(set(org + organisation))
    final_organisation = []
    valid_organisations = list(data_companies.keys())
    for organ in organisations:
        if organ.lower() not in valid_organisations:
            dispatcher.utter_message('{} is not a valid company'.format(organ))
        else:
            final_organisation.append(organ.lower())
    return final_organisation


class ValidateTwoOrganisationForm(FormValidationAction):
    def name(self) -> Text:
        return 'validate_two_organisation_form'

    async def required_slots(
        self,
        slots_mapped_in_domain: List[Text],
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain,
    ) -> List[Text]:
        return ['first_organ', 'second_organ']

    async def extract_first_organ(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain,
    ) -> Dict[Text, Optional[Any]]:
        returned_dict = {'first_organ': None}

        if tracker.get_slot('first_organ'):
            returned_dict['first_organ'] = tracker.get_slot('first_organ')
        else:
            organs = get_orgs(tracker, dispatcher)
            if organs:
                returned_dict['first_organ'] = organs[0]

        returned_dict['ORG'] = returned_dict['first_organ']
        return returned_dict

    async def extract_second_organ(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain,
    ) -> Dict[Text, Optional[Any]]:
        returned_dict = {'second_organ': None}
        organs = get_orgs(tracker, dispatcher)
        organs = [org for org in organs if org != tracker.get_slot('first_organ')]

        if organs:
            if tracker.get_slot('first_organ'):
                returned_dict['second_organ'] = organs[0]
            elif len(organs) > 1:
                returned_dict['second_organ'] = organs[1]

        returned_dict['ORG'] = returned_dict['second_organ']
        return returned_dict


class ValidateOneOrganisationForm(FormValidationAction):
    def name(self) -> Text:
        return 'validate_one_organisation_form'

    async def required_slots(
        self,
        slots_mapped_in_domain: List[Text],
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain,
    ) -> List[Text]:
        return ['first_organ']

    async def extract_first_organ(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain,
    ) -> Dict[Text, Optional[Any]]:
        returned_dict = {'first_organ': None}

        organs = get_orgs(tracker, dispatcher)
        if organs:
            returned_dict['first_organ'] = organs[0]
            returned_dict['ORG'] = organs[0]

        return returned_dict
