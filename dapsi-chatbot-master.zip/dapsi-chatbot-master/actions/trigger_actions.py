from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from actions.companies import data_companies
from rasa_sdk.events import AllSlotsReset
from actions.forms import get_orgs


def r_text(text):
    return {'type': 'text', 'content': text}


def r_card(companies):
    return {'type': 'card', 'content': [{'company_01': data_companies[company_1]['name'],
                                         'company_02': data_companies[company_2]['name'],
                                         'company_01_img': data_companies[company_1]['image'],
                                         'company_02_img': data_companies[company_2]['image'],
                                         'value': value}
                                        for company_1, company_2, value in companies]}


def r_button(buttons):
    return {'type': 'button', 'content': buttons}


def r_path(path):
    return {'type': 'path', 'content': path}


class ConfirmationUser(Action):
    def name(self) -> Text:
        return 'action_confirmation_user'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        username = list(tracker.get_latest_entity_values('username'))[0]
        response = [r_text('Great, {}! Give me a minute to set everything up'.format(username))]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class LoginDone(Action):
    def name(self) -> Text:
        return 'action_login_done'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text("Everything is ready for you. Let's dive in!")]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class LoginSmallTalk(Action):
    def name(self) -> Text:
        return 'action_login_small_talk'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text('Hello!'),
                    r_text('Welcome to Personal Data Store'),
                    r_text(
                        'Here we can help you find out what companies have your personal data, recover it and better control where it goes.'),
                    r_text('We can even help you make some money off you data, if you are interested.'),
                    r_text('Start by creating an account. '
                           'You can also browse anonymously.')]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class Offers(Action):
    def name(self) -> Text:
        return 'action_offers'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text(
            'There are some new offers in the marketplace that you may be interested in. Do you want to see it?'),
                    r_button(['Yes', 'No'])]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class OffersYes(Action):
    def name(self) -> Text:
        return 'action_offers_yes'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text("Okey! Let's see it"),
                    r_path('/marketplace')]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class Marketplace(Action):
    def name(self) -> Text:
        return 'action_marketplace'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        organisation = get_orgs(tracker, dispatcher)
        org_data = data_companies.get(organisation[0] if organisation else None)
        if org_data:
            response = [r_text("Let's see what offers there are for {}.".format(org_data.get('name'))),
                        r_path('/company-detail/{}?location=whoInterested'.format(org_data.get('id')))]
        else:
            response = [r_text("Let's go to the marketplace!."),
                        r_path('/marketplace')]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class MyData(Action):
    def name(self) -> Text:
        return 'action_mydata'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text('Right here you can see your data'),
                    r_path('/mydata')]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class Dashboard(Action):
    def name(self) -> Text:
        return 'action_dashboard'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text('Now you are in your dashboard'),
                    r_path('/dashboard')]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class DataAcademy(Action):
    def name(self) -> Text:
        return 'action_data_academy'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text('In data academy you will learn a lot!'),
                    r_path('/data-academy')]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]


class Cards(Action):
    def name(self) -> Text:
        return 'action_cards'

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        response = [r_text('Aqui tienes tus cards'),
                    r_card([['amazon', 'alibaba', 'Amazon <br> Video settings <br> Alibaba'],
                            ['fnac', 'el corte ingles', 'Fnac <br> Video settings <br> El Corte Ingés']])]
        dispatcher.utter_custom_json({'events': response})
        return [AllSlotsReset()]
