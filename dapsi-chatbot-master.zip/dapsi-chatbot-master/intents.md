# Intents
Intents are the intentions that the chatbot can understand and respond to. This chatbot understands the following:

Intents triggered by text
-
  - faqs: Faqs about gdpr
    - What is gdpr?
    - Who must comply with the GDPR?
    - What are the GDPR fines?
    
  - chitchat: Small talk without meaning
    - hi
    - wow
    - good morning
    
  - organisation_schema: ask about an company data schema
    - data schema of amazon
    - what is the netflix data schema?
    
  - schema_comparison: compare data schema of two different companies
    - differences between amazon and netflix
    - what information is different between alibaba and disney
    
  - confirmation.cancel: When the user says something like cancel
    - cancel
    - cancel it
    
  - confirmation.yes: When the user affirms
    - yes
    - right
    
  - confirmation.no: When the user denies
    - no
    - don't
    
  - data_academy: Phrases to go to data academy menu
    - data academy
    - i want to see data academy
    
  - marketplace: Phrases to go to marketplace menu
    - marketplace
    - i want to see marketplace
    
  - my_data: Phrases to go to my data menu
    - my data
    - i want to see my data
    
  - dashboard: Phrases to go to dashboard menu
    - dashboard
    - i want to see dashboard
    
  - organisation: Phrases with the name of a company
    - amazon
    - from netflix
    
  - recover_data: When user wants to recover their data from a company
    - recover data from amazon
    - i want to recover my data from netflix
    
  - what_data_have: When the user asks about what of their data has a company
    - what data has bbva of me
    - my data in inditex
    
  - what_can_you_do: An intent of what the chatbot can do
    - what can you do?
    - what can do?
    
  - what_is_my_data: When user asks about what is my data menu
    - what is the my data?
    - what is the my data menu?
    
  - what_is_marketplace: When user asks about what is marketplace menu
    - what is the marketplace?
    - what is the marketplace menu?
    
  - what_is_data_academy: When user asks about what is data academy menu
    - what is the menu data academy?
    - what is data academy?
    
  - what_is_dashboard: When user asks about what is dashboard menu
    - what can i do in dashboard menu?
    - what can i do in the menu dashboard?
    
Intents triggered by custom petition
-
  - confirmation_user: When a user enters their credentials correctly
    - entities: username
  - login_small_talk: First contact with the user before login
  - login_done: When login ends
  - offers: The user has offers