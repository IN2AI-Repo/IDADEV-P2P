# Dapsi - Chatbot

This chatbot is designed to be used by Dapsi - GUI.
That means there will be responses with information specific to that GUI and not in natural text language.

## Instalation

### Environment

action_server=url for the action server of rasa, usually localhost

### Run IDADEV_CHATBOT Quick Start

Quick start requisites: 
- [docker](https://docs.docker.com/engine/install/ubuntu/) must be installed 
- [docker-compose](https://docs.docker.com/compose/install/) must be installed
- make is optional (should be instaled by default, but if it's not: ```sudo apt-get install build-essential```)

#### With Make and Docker:
2. ```make``` or ```make all```

With this Makefile you can also use:
- train: Create a docker and train the model. It will be removed after being stopped
- start: start the docker compose (rasa model, action server, duckling http extractor and elastic search services)
- stop: stop the docker compose
- restart_actions: refresh the action server (useful if the python code is changed)
- restart_rasa: retrain the model and refresh custom action and the model
- restart: restart all services

#### With docker:
1. Train the model 
    ```
    docker run --rm --env -u root -v $(pwd):/app rasa/rasa:2.1.1-full train --domain domain --data data --out models
    ```
2. Start services using ```docker-compose up```

### Run IDADEV_CHATBOT Using Rasa and Python

Rasa start requisites:
- Python 3.8 env
- Requirement installed: ```pip install -r requirements.txt```
- Download pretrained vector from spacy: 
````
python -m spacy download en_core_web_md  
python -m spacy link en_core_web_md en 
````

1. Export the env params (action_server)
2. Train the model using ```rasa train --domain domain --data data```
3. With one console run ```rasa run actions``` to have the custom actions server running
4. With another console run ```rasa shell```if you want to talk directly with rasa, or ```rasa run [--enable-api --cors "*"]``` to have a server with rasa running

## How to use:

Here you can see a list of all the intents that the chatbot supports: [intents](intents.md)

In order to make a petition to the rasa server, here we have an example with curl:

Send a message
```
curl --location --request POST 'http://{IP: localhost:5005}/webhooks/rest/webhook' \
--data-raw '{
  "sender": "{unique_id: id}",
  "message": "{message: what is gdpr?}"
}'
```

Trigger an  intent
```
curl --location --request POST 'http://localhost:5005/conversations/{unique_id: id}/trigger_intent' \
--header 'Content-Type: text/plain' \
--data-raw '{
    "name": "{intent: offers}",
    "entities": "{object: {"prueba": 2}}
}'
```


